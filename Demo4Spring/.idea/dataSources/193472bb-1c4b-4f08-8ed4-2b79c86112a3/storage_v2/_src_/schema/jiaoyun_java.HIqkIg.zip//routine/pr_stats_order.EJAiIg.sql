CREATE PROCEDURE pr_stats_order()
  BEGIN

  DECLARE v_start_time DATETIME DEFAULT DATE_ADD(CURDATE(), INTERVAL -1 DAY);
  DECLARE v_end_time   DATETIME DEFAULT DATE_ADD(CURDATE(), INTERVAL -1 SECOND);
  DECLARE v_idx        INT      DEFAULT 0;

  WHILE v_idx < 24
  DO

    INSERT INTO `nc_stats_order_time`
      (`stats_date`, `stats_hour`, `order_cnt`, `grab_order_cnt`)
    SELECT *
      FROM (SELECT DATE(v_start_time),
                   v_idx,
                   COUNT(IF(HOUR(`create_time`) = v_idx, 1, NULL)) order_cnt, 
                   COUNT(IF(HOUR(`create_time`) = v_idx AND `drv_id` IS NOT NULL, 1, NULL)) grab_order_cnt 
             FROM `nc_order`
            WHERE `create_time` BETWEEN v_start_time AND v_end_time) b
        ON DUPLICATE KEY UPDATE `order_cnt` = b.order_cnt,
                                `grab_order_cnt` = b.grab_order_cnt;

    INSERT INTO `nc_stats_order_time`
      (`stats_date`, `stats_hour`, `finish_order_cnt`)
    SELECT *
      FROM (SELECT DATE(v_start_time) stats_date,
                   v_idx stats_hour,
                   COUNT(IF(HOUR(`off_time`) = v_idx, 1, NULL)) finish_order_cnt 
              FROM nc_order
             WHERE order_status = 7
               AND off_time BETWEEN v_start_time AND v_end_time) b
        ON DUPLICATE KEY UPDATE `finish_order_cnt` = b.finish_order_cnt;

    INSERT INTO `nc_stats_order_time`
      (`stats_date`, `stats_hour`, `cancel_order_cnt`)
    SELECT *
      FROM (SELECT DATE(v_start_time) stats_date,
                   v_idx stats_hour,
                   COUNT(IF(HOUR(`update_time`) = v_idx, 1, NULL)) cancel_order_cnt 
              FROM nc_order
             WHERE order_status in (3, 4)
               AND update_time BETWEEN v_start_time AND v_end_time) b
        ON DUPLICATE KEY UPDATE `cancel_order_cnt` = b.cancel_order_cnt;

    SET v_idx = v_idx + 1; 
  END WHILE;

  DELETE FROM `nc_stats_order_time`
   WHERE `stats_date` = DATE(v_start_time)
     AND `order_cnt` = 0
     AND `grab_order_cnt` = 0
     AND `finish_order_cnt` = 0
     AND `cancel_order_cnt` = 0;

  INSERT INTO `nc_stats_order`
    (`stats_date`, `order_cnt`, `pre_order_money`, `grab_order_cnt`)
  SELECT *
    FROM (SELECT DATE(v_start_time),
                 COUNT(1) order_cnt, 
                 SUM(pre_money) pre_order_money, 
                 COUNT(IF(drv_id is not null, 1, null)) grab_order_cnt 
            FROM nc_order
           WHERE create_time BETWEEN v_start_time AND v_end_time) b
      ON DUPLICATE KEY UPDATE `order_cnt` = b.`order_cnt`,
                              `pre_order_money` = b.`pre_order_money`,
                              `grab_order_cnt` = b.`grab_order_cnt`;

  INSERT INTO `nc_stats_order`
    (`stats_date`, `finish_order_cnt`, `deal_money`, `deal_mile`, `max_mile`, `min_mile`, `avg_mile`)
  SELECT *
    FROM (SELECT DATE(v_start_time) stats_date,
                 COUNT(1) finish_order_cnt,  
                 SUM(total_money) deal_money, 
                 SUM(real_mile) deal_mile, 
                 MAX(real_mile) max_mile, 
                 MIN(real_mile) min_mile, 
                 AVG(real_mile) avg_mile 
            FROM nc_order
           WHERE order_status = 7
             AND off_time BETWEEN v_start_time AND v_end_time) b
      ON DUPLICATE KEY UPDATE `finish_order_cnt` = b.finish_order_cnt,
                              `deal_money` = b.deal_money,
                              `deal_mile` = b.deal_mile,
                              `max_mile` = b.max_mile,
                              `min_mile` = b.min_mile,
                              `avg_mile` = b.avg_mile;

  INSERT INTO `nc_stats_order`
    (`stats_date`, `pay_money`, `wechat_pay_cnt`, `alipay_cnt`)
  SELECT *
    FROM (SELECT DATE(v_start_time) stats_date,
                 SUM(pay_money) pay_money, 
                 COUNT(IF(pay_way = 1, 1, NULL)) wechat_pay_cnt, 
                 COUNT(IF(pay_way = 2, 1, NULL)) alipay_cnt 
            FROM nc_order
           WHERE pay_time BETWEEN v_start_time AND v_end_time) b
      ON DUPLICATE KEY UPDATE `pay_money` = b.pay_money,
                              `wechat_pay_cnt` = b.wechat_pay_cnt,
                              `alipay_cnt` = b.alipay_cnt;

  INSERT INTO `nc_stats_order`
    (`stats_date`, `timeout_order_cnt`, `timeout_order_money`)
  SELECT *
    FROM (SELECT DATE(v_start_time) stats_date,
                 COUNT(1) timeout_order_cnt, 
                 SUM(pre_money) timeout_order_money 
            FROM nc_order
           WHERE order_status = 9
             AND update_time BETWEEN v_start_time AND v_end_time) b
      ON DUPLICATE KEY UPDATE `timeout_order_cnt` = b.timeout_order_cnt,
                              `timeout_order_money` = b.timeout_order_money;

  INSERT INTO `nc_stats_order`
    (`stats_date`, `psg_cancel_order_cnt`, `drv_cancel_order_cnt`, `cancel_order_money`)
  SELECT *
    FROM (SELECT DATE(v_start_time) stats_date,
                 COUNT(IF(order_status = 3, 1, NULL)) psg_cancel_order_cnt, 
                 COUNT(IF(order_status = 4, 1, NULL)) drv_cancel_order_cnt, 
                 SUM(pre_money) cancel_order_money 
            FROM nc_order
           WHERE order_status in (3, 4)
             AND update_time BETWEEN v_start_time AND v_end_time) b
      ON DUPLICATE KEY UPDATE `psg_cancel_order_cnt` = b.psg_cancel_order_cnt,
                              `drv_cancel_order_cnt` = b.drv_cancel_order_cnt,
                              `cancel_order_money` = b.cancel_order_money;

END;

